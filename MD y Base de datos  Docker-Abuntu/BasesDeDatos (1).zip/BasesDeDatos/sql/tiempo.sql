-- =========================================================
-- tiempo.sql (versi�n SQL Server)
-- Configuraci�n de tiempo y tama�o de operaciones grandes
-- =========================================================
USE master;
GO

-- Habilitar opciones avanzadas
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
GO

-- Aumentar el tama�o m�ximo de paquetes de red (m�ximo 2 GB)
EXEC sp_configure 'network packet size', 32767;  -- en bytes (m�ximo permitido)
RECONFIGURE;
GO

-- Ajustar tiempo de espera de conexiones remotas
EXEC sp_configure 'remote query timeout', 28800;  -- 8 horas (en segundos)
RECONFIGURE;
GO

-- Ajustar timeout de consultas locales (solo aplica a tiempo de ejecuci�n en cliente)
-- Nota: SQL Server no tiene wait_timeout global como MySQL; 
-- se define en el nivel de conexi�n del cliente (por ejemplo, en la cadena de conexi�n).
-- Para simularlo en entornos de prueba:
SET LOCK_TIMEOUT 28800000;  -- 8 horas (en milisegundos)
GO


DROP DATABASE CafeteriaDigital;


